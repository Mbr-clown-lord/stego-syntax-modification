def binary_to_ascii(binary: str) -> str:

    chars = [chr(int(binary[i:i+8], 2)) for i in range(0, len(binary), 8)]
    return ''.join(chars)
def read_binary_from_file(filename: str) -> str:
    with open(filename, 'r') as file:
        return file.read().strip()

binary_str = read_binary_from_file("binary.txt")
plaintext = binary_to_ascii(binary_str)
print("Message:", plaintext)
