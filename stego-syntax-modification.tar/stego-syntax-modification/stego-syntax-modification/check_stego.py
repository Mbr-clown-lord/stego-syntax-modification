import re

def classify_sentence(sentence: str) -> str:
    sentence = sentence.strip()
    has_front_adverb = bool(re.match(r'^(Vào|Trong|Trước|Sau|Từ|Kể từ)', sentence))
    is_passive = bool(re.search(r'được\s+\w+|\s+được\s+trình bày|được\s+ứng dụng|được\s+ký kết', sentence))
    if not is_passive and not has_front_adverb:
        return '00'
    elif not is_passive and has_front_adverb:
        return '01'
    elif is_passive and not has_front_adverb:
        return '10'
    else:
        return '11'

def extract_bits_from_paragraph(paragraph: str, target_sentences: list) -> str:
    sentences = [s.strip() for s in re.split(r'(?<=[.!?])\s+', paragraph) if s.strip()]
    return ''.join(classify_sentence(sentences[i]) for i in target_sentences if i < len(sentences))

def binary_to_ascii(binary: str) -> str:
    chars = []
    for i in range(0, len(binary), 8):
        byte = binary[i:i+8]
        if len(byte) < 8:
            continue
        char = chr(int(byte, 2))
        if char not in '0123456789':
            print("Error")
            exit()
        chars.append(char)
    return ''.join(chars)

with open('input.txt', 'r', encoding='utf-8') as f:
    paragraph = f.read()

target_lines = [0, 2, 4, 6]

bitstream = extract_bits_from_paragraph(paragraph, target_lines)
plaintext = binary_to_ascii(bitstream)

print("Message:", plaintext)

